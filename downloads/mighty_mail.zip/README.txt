Add the following file to your mods folder

    - mighty_mail-forge-1.20.1-1.0.14.jar
    - framework-forge-1.20.1-0.7.6.jar